tawk/tawk-whmcs
================

# About tawk.to
tawk.to is a  free  live chat app that lets you monitor and  chat  with  visitors on your website
or from a free customizable page. No catch. No spam. No wares. It's truly free and always will be.

# Installation
Copy files modules folder to your whmcs installation folder. After that you will have to activate
it by going to Setup -> Addon modules (admin/configaddonmods.php) and finding and activating
Tawk.to widget module. Then make sure that you configure access to this module so that you have access to it.


If you don't have [tawk.to](https://tawk.to/?utm_source=whmcs&utm_medium=link&utm_campaign=signup) account, you can always [create one for free](https://tawk.to/?utm_source=whmcs&utm_medium=link&utm_campaign=signup)